
//The below function will permits 3 arguments that will be used to generate a response statement based on the arguments.
//This function will also return the variable greeting to the function 'greetings()'

function Count_Dooku(name, time, date) {
    var greeting = ("Good day, " + name + "! It is " + time + " on " + date + ".");
    console.log(greeting);
    console.log("I'm coming for you, Dooku!");
    return(greeting)
}
Count_Dooku("Frank","1300 hrs","Tuesday, 21 May 2023")



