
function upAndAway() {
    var increase = document.querySelector('#goingUpOne');
    increase.innerText++
}

function upAndAwayTwo() {
    var increase = document.querySelector('#goingUpTwo');
    increase.innerText++
}

function upAndAwayThree() {
    var increase = document.querySelector('#goingUpThree');
    increase.innerText++
}